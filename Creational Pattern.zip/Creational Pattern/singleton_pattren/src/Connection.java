
class Connection {
    private String status;

    public Connection(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }
}
