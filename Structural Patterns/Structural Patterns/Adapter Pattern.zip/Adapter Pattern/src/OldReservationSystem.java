class OldReservationSystem {
    public void reserveTable(String customerName, int tableNumber) {
        System.out.println("Reservation confirmed for " + customerName + " table " + tableNumber + " Menggunakan Sistem Reservasi Lama.");
    }
}