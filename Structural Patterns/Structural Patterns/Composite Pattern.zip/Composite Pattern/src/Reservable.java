interface Reservable {
    void reserve();
    void release();
    boolean isReserved();
}
